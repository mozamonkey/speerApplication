//
//  cameraFile.h
//  uOttawa
//
//  Created by Mathew Mozaffari on 2018-02-18.
//  Copyright © 2018 Mathew Mozaffari. All rights reserved.
//

#ifndef cameraFile_h
#define cameraFile_h

#import ClarifaiApp.h

#endif /* cameraFile_h */
