//
//  PreviewViewController.swift
//  uOttawa
//
//  Created by Mathew Mozaffari on 2018-02-18.
//  Copyright © 2018 Mathew Mozaffari. All rights reserved.
//

import UIKit

class PreviewViewController: UIViewController {
    
    @IBAction func cancelTapped(_ sender: Any) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    
}
